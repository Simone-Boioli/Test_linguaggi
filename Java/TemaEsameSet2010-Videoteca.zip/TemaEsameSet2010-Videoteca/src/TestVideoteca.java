import junit.framework.TestCase;


public class TestVideoteca extends TestCase {
	public void testDelTemaDEsame(){
		Videoteca v = new Videoteca();
		Utente marco = new Utente("Marco");
		Utente pippo = new Utente("Pippo");
		v.addUtente(marco);
		v.addUtente(pippo);
		int[] scene1 = {1800, 1800, 900, 300};
		Film f1 = new Film("L'esorcista", scene1, 4);
		int[] scene2 = {1800, 900, 900, 3659};
		Film f2 = new Film("Suspiria", scene2, 4);
		v.addFilm(f1);
		v.addFilm(f2);
		int prezzo;
		prezzo = v.getUtentePerNome("marco").prendiInPrestito(v, "suspiria");
		assertEquals(8, prezzo);
		prezzo = v.getUtentePerNome("marco").prendiInPrestito(v, "l'esorcista");
		assertEquals(6, prezzo);
		prezzo = v.getUtentePerNome("pippo").prendiInPrestito(v, "suspiria");
		assertEquals(-2, prezzo);
		prezzo = v.getUtentePerNome("pippo").prendiInPrestito(v, "l'esorcista");
		assertEquals(-2, prezzo);
	}
	public void testConPiuControlli(){
		Videoteca v = new Videoteca();
		Utente marco = new Utente("Marco");
		Utente pippo = new UtenteTesseraFidaty("Pippo");
		v.addUtente(marco);
		v.addUtente(pippo);
		int[] scene1 = {1800, 1800, 900, 300};
		Film f1 = new Film("L'esorcista", scene1, 4);
		int[] scene2 = {1800, 900, 900, 3659};
		Film f2 = new Film("Suspiria", scene2, 4);
		v.addFilm(f1);
		v.addFilm(f2);
		int prezzo;
		prezzo = v.getUtentePerNome("marco").prendiInPrestito(v, "suspiria");
		assertEquals(8, prezzo);
		prezzo = v.getUtentePerNome("marco").prendiInPrestito(v, "l'esorcista");
		assertEquals(6, prezzo);
		prezzo = v.getUtentePerNome("pippo").prendiInPrestito(v, "nonso");
		assertEquals(-1, prezzo);
		prezzo = v.getUtentePerNome("pippo").prendiInPrestito(v, "suspiria");
		assertEquals(-2, prezzo);
		v.getUtentePerNome("marco").restituisciTutti();
		prezzo = v.getUtentePerNome("pippo").prendiInPrestito(v, "suspiria");
		assertEquals(8, prezzo);
	}
}
