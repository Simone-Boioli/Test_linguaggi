import java.util.Vector;


public class Utente {
	/* Un utente caratterizzato da un nome e da un insieme (inzialmente vuoto)
	 * di film in prestito*/
	private String nome;
	private Vector<Film> filmInPrestito;

	public Utente(String nome) {
		this.nome = nome;
		this.filmInPrestito = new Vector<Film>();
	}

	public String getNome() {
		return nome;
	}
	
	/* Permette all'utente di prendere in prestito un film 
	 * con titolo "titolo" dalla videoteca "v".
	 * Restituisce il prezzo da pagare per il prestito.
	 * Casi particolari:
	 * 		se il film non esiste nel catalogo della videoteca, restituisce -1;
	 * 		se il film esiste in catalogo, ma non � possibile affittarlo, restituisce -2
	 */
	public int prendiInPrestito(Videoteca v, String titolo){
		Film f = v.getFilmInCatalogo(titolo);
		if(f == null) return -1;
		if(f.affitta()){
			this.filmInPrestito.add(f);
			return f.getPrezzo_euro();
		}
		return -2;
	}
	
	/* restisuisce tutti i film in prestito all'utente */
	public void restituisciTutti(){
		while(!this.filmInPrestito.isEmpty()){
			this.filmInPrestito.firstElement().retsituisci();
			this.filmInPrestito.remove(0);
		}
	}
}
