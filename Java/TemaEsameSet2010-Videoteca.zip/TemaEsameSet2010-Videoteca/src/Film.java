
public class Film {
	/* Un utente caratterizzato da un titolo, 
	 * dalla disponibilit� per prestito (inizialmente true),
	 * dall'insieme delle durate (in secondi) delle scene del film
	 * e da un costo d�affitto unitario per ora di durata del film
	 * */
	private String titolo;
	private boolean disponibile;
	private int[] durataScene_secondi;
	private int costoPerOra_euro;
	public Film(String titolo, int[] durataScene, int costoPerOra_euro){
		this.titolo = titolo;
		this.durataScene_secondi = durataScene;
		this.costoPerOra_euro = costoPerOra_euro;
		this.disponibile = true;
	}
	public String getTitolo(){
		return this.titolo;
	}
	/* Restituisce la durata totale (in secondi) del film,
	 * ottenuta come somma delle durate di tutte le scene del film
	 * */
	public int getDurataInSecondi(){
		int durata = 0;
		for(int i = 0; i < this.durataScene_secondi.length; i++)
			durata += this.durataScene_secondi[i];
		return durata;
	}

	/* Restituisce il prezzo del film, pari a costoPerOra_euro ogni 3600 secondi
	 * di durata, aggiungendo al totale 2 euro nel caso ci siano dei minuti (60 secondi)
	 * aggiuntivi oltre le ore calcolate (attenzione: aggiungere solo 2 euro; 
	 * non due euro per ogni minuto!)
	 * */
	public int getPrezzo_euro(){
		int durata = getDurataInSecondi();
		int prezzo = this.costoPerOra_euro * (durata / 3600);
		if((durata % 3600) >= 60) prezzo += 2;
		return prezzo;
	}
	
	/* Determina se il film pu� essere affitato, verificandone la disponibilit�.
	 * In caso di risposta affermativa, il verr� considerato affittaro, e quindi
	 * non pi� disponibile
	 * */
	public boolean affitta(){
		if(disponibile == true){
			disponibile = false;
			return true;
		}
		else return false;
	}
	
	/* Restituisce il film, ripristandone quindi la disponibilit� */
	public void retsituisci(){
		disponibile = true;
	}
}
