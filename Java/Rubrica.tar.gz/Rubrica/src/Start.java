public class Start {
	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		Finestra finestra = new Finestra();
		

	}

}
